//
//  SQLite3_TestViewController.h
//  SQLite3_Test
//
//  Created by SOHAMPAUL on 21/06/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQLite3_TestViewController : UIViewController <UITextFieldDelegate>{
	UITextField *nameTxt;
	UITextField *yearTxt;
	UITextField *streamTxt;
	UITextField *ageTxt;
	NSMutableArray *dataSet;
}
-(void)insertRetriveData;
-(void)submitToSql;
@end

