//
//  SQLite3_TestAppDelegate.h
//  SQLite3_Test
//
//  Created by SOHAMPAUL on 21/06/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SQLite3_TestViewController;

@interface SQLite3_TestAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SQLite3_TestViewController *viewController;
	UINavigationController *nav;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SQLite3_TestViewController *viewController;

@end

