//
//  SQLite3_TestViewController.m
//  SQLite3_Test
//
//  Created by SOHAMPAUL on 21/06/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SQLite3_TestViewController.h"
#import<sqlite3.h>
#import "DataDetails.h"
@implementation SQLite3_TestViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
	[textField resignFirstResponder];
	self.view.frame=CGRectMake(0, 0, 320, 460);
	return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
	if (textField.tag==2 || textField.tag==1) {
		self.view.frame=CGRectMake(0, -40, 320, 460);
	}
	return YES;
	
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.navigationItem.title=@"SQLite 3";
	
	dataSet=[[NSMutableArray alloc]init];
	
	
	UILabel *studentName=[[UILabel alloc]initWithFrame:CGRectMake(30, 50, 100, 40)];
	studentName.backgroundColor=[UIColor clearColor];
	studentName.text=@"Name";
	[self.view addSubview:studentName];
	
	
	UILabel *classYear=[[UILabel alloc]initWithFrame:CGRectMake(30, 100, 100, 40)];
	classYear.backgroundColor=[UIColor clearColor];
	classYear.text=@"Year";
	[self.view addSubview:classYear];
	
	UILabel *stream=[[UILabel alloc]initWithFrame:CGRectMake(30, 150, 100, 40)];
	stream.backgroundColor=[UIColor clearColor];
	stream.text=@"Stream";
	[self.view addSubview:stream];
	
	
	UILabel *studentAge=[[UILabel alloc]initWithFrame:CGRectMake(30, 200, 100, 40)];
	studentAge.backgroundColor=[UIColor clearColor];
	studentAge.text=@"Age";
	[self.view addSubview:studentAge];
	
	
	nameTxt=[[UITextField alloc]initWithFrame:CGRectMake(90, 50, 200, 30)];
	nameTxt.backgroundColor=[UIColor whiteColor];
	nameTxt.delegate=self;
	nameTxt.placeholder=@"Student Name";
	[self.view addSubview:nameTxt];
	
	yearTxt=[[UITextField alloc]initWithFrame:CGRectMake(90, 100, 200, 30)];
	yearTxt.backgroundColor=[UIColor whiteColor];
	yearTxt.placeholder=@"Year";
	yearTxt.delegate=self;
	[self.view addSubview:yearTxt];
	
	streamTxt=[[UITextField alloc]initWithFrame:CGRectMake(90, 150, 200, 30)];
	streamTxt.backgroundColor=[UIColor whiteColor];
	streamTxt.placeholder=@"Stream";
	streamTxt.delegate=self;
	streamTxt.tag=1;
	[self.view addSubview:streamTxt];
	
	ageTxt=[[UITextField alloc]initWithFrame:CGRectMake(90, 200, 200, 30)];
	ageTxt.backgroundColor=[UIColor whiteColor];
	ageTxt.placeholder=@"Student Age";
	ageTxt.delegate=self;
	ageTxt.tag=2;
	[self.view addSubview:ageTxt];
	
	
	UIButton *submitButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	[submitButton setTitle:@"Submit Data" forState:UIControlStateNormal];
	[submitButton addTarget:self action:@selector(submitToSql) forControlEvents:UIControlEventTouchUpInside];
	submitButton.frame = CGRectMake(60, 300, 200, 40);
	[self.view addSubview:submitButton];
	
	
	
	
}
-(void)submitToSql{
	[self insertRetriveData];
	DataDetails *dataDetailClass=[[DataDetails alloc ]initwithDataArray:dataSet];	
	[self.navigationController pushViewController:dataDetailClass animated:YES];
}

-(NSString *) filePath {
	
    NSArray *paths = NSSearchPathForDirectoriesInDomains(
														 
														 NSDocumentDirectory, NSUserDomainMask, YES);
	
    NSString *documentsDir = [paths objectAtIndex:0];
	
    return [documentsDir stringByAppendingPathComponent:@"databaseNotes.sql"];
	
}

-(void)insertRetriveData
{
	UIAlertView *view;
	
	sqlite3 *database;
	int result = sqlite3_open([[self filePath] UTF8String], &database);
	if(result != SQLITE_OK)
	{
		sqlite3_close(database);
		view = [[UIAlertView alloc]
				initWithTitle: @"Database Error"
				message: @"Failed to open database."
				delegate: self
				cancelButtonTitle: @"Hrm." otherButtonTitles: nil];
		[view show];
		[view autorelease];
		return;
	}
	
	sqlite3_exec(database,
				 "CREATE TABLE IF NOT EXISTS DATABASE_TABLE (ID INTEGER PRIMARY KEY AUTOINCREMENT,nameTxt TEXT,yearTxt TEXT,streamTxt TEXT,ageTxt TEXT)",
				 NULL, NULL, NULL);
	
	sqlite3_exec(database, [[NSString stringWithFormat:
							 @"INSERT INTO DATABASE_TABLE VALUES(NULL, '%@','%@','%@','%@')", 
							 nameTxt.text,yearTxt.text,streamTxt.text,ageTxt.text] 
							UTF8String],NULL, NULL, NULL);   
	
	sqlite3_stmt *statement;
	sqlite3_prepare_v2(database, "SELECT * FROM DATABASE_TABLE", -1, &statement, nil);
	[dataSet removeAllObjects];
	while(sqlite3_step(statement) == SQLITE_ROW)
	{
		NSString *name = [[NSString alloc] initWithUTF8String:
							 (char *)sqlite3_column_text(statement, 1)];
		NSString *year = [[NSString alloc] initWithUTF8String:
							 (char *)sqlite3_column_text(statement, 2)];
		NSString *stream = [[NSString alloc] initWithUTF8String:
							 (char *)sqlite3_column_text(statement, 3)];
		NSString *age = [[NSString alloc] initWithUTF8String:
							 (char *)sqlite3_column_text(statement, 4)];
		[dataSet addObject:name]; 
		[dataSet addObject:year]; 
		[dataSet addObject:stream]; 
		[dataSet addObject:age]; 
		[name release];
		[year release];
		[stream release];
		[age release];
		
	}
	NSLog(@"SQL Database==>>%@",dataSet);
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[dataSet removeAllObjects];
    [super dealloc];
}

@end
