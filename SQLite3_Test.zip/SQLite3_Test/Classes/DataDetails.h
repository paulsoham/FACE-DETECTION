//
//  DataDetails.h
//  SQLite3_Test
//
//  Created by SOHAMPAUL on 21/06/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DataDetails : UIViewController {

}
-(id)initwithDataArray:(NSMutableArray *)DataBaseArray;
@end
